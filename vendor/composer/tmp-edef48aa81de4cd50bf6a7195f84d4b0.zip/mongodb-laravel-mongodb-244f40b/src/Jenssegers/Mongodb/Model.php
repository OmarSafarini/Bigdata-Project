<?php namespace Jenssegers\Mongodb;

use Jenssegers\Mongodb\Eloquent\Model as BaseModel;

abstract class Model extends BaseModel
{
}
